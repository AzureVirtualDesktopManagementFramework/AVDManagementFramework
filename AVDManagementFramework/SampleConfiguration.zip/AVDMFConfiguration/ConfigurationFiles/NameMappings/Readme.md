 To use this locally, create a file named EnironmentVariables.json in the configuration and provide desired values for each variable. Remember to add the file to .gitignore"

 At the moment, this is only used for OU Path.